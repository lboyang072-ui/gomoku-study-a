import { createExperimentSession } from './experiment-session.mjs';
import { FORM_IDS, formForPair, isPairId, loadForm } from './forms.mjs';
import { evaluate_move } from './engine/engine.mjs';

const $=s=>document.querySelector(s);
const ui={notice:$('#notice'),toast:$('#toast'),fatal:$('#fatal'),fatalMessage:$('#fatal-message'),start:$('#start-panel'),hostReady:$('#host-ready-panel'),run:$('#run-panel'),questionnaire:$('#questionnaire'),complete:$('#complete-panel'),languageToggle:$('#language-toggle'),mode:()=>document.querySelector('input[name="mode"]:checked')?.value??'demo',condition:()=>document.querySelector('input[name="condition"]:checked')?.value??'control',consent:$('#consent'),startButton:$('#start-run'),startModePill:$('#start-mode-pill'),modeChoice:document.querySelector('fieldset.mode-choice:not(.compact)'),hostAssignment:$('#host-assignment'),hostConditionLabel:$('#host-condition-label'),hostPairLabel:$('#host-pair-label'),hostReadySummary:$('#host-ready-summary'),hostBeginRun:$('#host-begin-run'),hostReturnConsent:$('#host-return-consent'),demoCondition:$('#demo-condition'),stage:$('#run-stage'),title:$('#run-title'),instruction:$('#run-instruction'),timer:$('#timer'),timerLabel:$('#timer-label'),progress:$('#progress-fill'),meta:$('#run-meta'),board:$('#experiment-board'),phasePanel:$('#phase-panel'),phaseCopy:$('#phase-copy'),selected:$('#selected-readout'),phaseButton:$('#phase-primary'),advice:$('#advice-card'),adviceTitle:$('#advice-title'),adviceCopy:$('#advice-copy'),stepCount:$('#step-count'),withdraw:$('#withdraw'),withdrawConfirmation:$('#withdraw-confirmation'),withdrawContinue:$('#withdraw-continue'),withdrawConfirm:$('#withdraw-confirm'),finish:$('#finish-questionnaire'),completeTitle:$('#complete-title'),completeSummary:$('#complete-summary'),completeWarning:$('#completion-warning'),exportJson:$('#export-json'),next:$('#next-participant')};
let language=new URLSearchParams(location.search).get('lang')==='en'?'en':'zh-CN';
let formId='A',hostLink=null,study=null,session=null,timerId=null,lastRenderKey=null,hostReady=false,withdrawalSubmitting=false;
const t={
 'zh-CN':{title:'A套五子棋决策试跑',description:'A套五子棋决策练习本机试跑',brand:'试跑',brandPrefix:'棋间',brandAria:'返回主持人页',pill:'A套 · 数据保存在本机',heroEyebrow:'FORM A · 10 ITEMS',hero:'独立判断，<em>再复查一步。</em>',intro:'3道基础测 · 4道练习 · 3道无AI后测。所有记录只保存在当前浏览器。',startEyebrow:'START',startTitle:'开始 A 套',localPilot:'本机试跑',startIntro:'请先阅读说明并同意参与。无需填写姓名、学号或联系方式。匿名编号会由本机生成。',modeLegend:'运行模式',demoMode:'演示模式',demoModeHelp:'可手动选择 AI 或对照条件；记录标记为 demo。',pilotMode:'本机试跑记录',pilotModeHelp:'按本机成对区组顺序分配 AI/对照；不是已批准的正式收数。',conditionLegend:'演示条件',ai:'AI建议',control:'自行复查',consentTitle:'参与说明',consentBullets:['本活动包含10道一步攻防判断题，预计需约15–20分钟；实际用时以页面记录为准。','你可随时退出；已完成的本机记录会保留并可导出。','基础测和后测不展示建议或正误反馈；练习阶段初选锁定后才显示条件提示。','编号、选择、用时、问卷回答及版本信息保存在本机；演示数据与试跑数据分开标记。','静态网页材料可能被技术检查；本版本不保证答案或建议对熟悉源文件的人保密。'],consent:'我已阅读说明，自愿参加本次本机试跑；我知道可以随时退出。',begin:'开始基础测 →',hostAssignment:'主持人分配',hostAssignmentAI:'主持人分配：AI建议',hostAssignmentControl:'主持人分配：自行复查',pairId:'配对编号：{id}',pairMissing:'未提供配对编号',hostLock:'该条件由主持人预先分配；本页不会提供切换入口。',agreeWait:'同意并进入等待开始',readyEyebrow:'READY · A',readyTitle:'已准备，等待主持人口令',readyIntro:'计时尚未开始。请等主持人确认两位参与者都准备好并给出统一口令；口令后在本设备点击下方按钮开始。本页不会远程启动或同步另一台设备。',returnInfo:'返回说明',beginAfterCue:'口令后开始 A 套',stage:{baseline:'基础测',practice:'正式练习',posttest:'无AI后测'},youPlay:'你执',black:'黑',white:'白',moveObjective:{win:'轮到当前方，请落一子立即形成五连或更长连续线。',block:'轮到当前方，请落一子阻止对方所有下一手成五点；己方直接成五获胜同样正确。'},timerLeft:'剩余时间',timerInitial:'初选剩余',timerReview:'本题剩余',demo:'演示',pilot:'本机试跑',aiCondition:'AI条件',controlCondition:'对照条件',noFeedback:'仅记录选择，不在本页显示正误',blackStone:'黑棋',whiteStone:'白棋',empty:'空点',board:'棋盘',boardCorner:'棋盘，左上A1',legendBlack:'黑方',legendWhite:'白方',keyboard:'方向键移动 · Enter选择',selection:'当前选择',waiting:'—',baselineCopy:'请独立选择一个落点并确认。本阶段不显示建议或正误反馈。',practiceInitial:'请先独立选择一个落点。确认后初选将锁定，随后进入复查阶段。',lockInitial:'锁定初选',practiceReview:'初选已锁定：{move}。可保留，也可在棋盘选一个最终落点后提交。',adviceMissing:'建议不可用',adviceMissingText:'本题建议材料缺失，已暂停该运行。',adviceMove:'建议落点：{move}',neutralReview:'自行复查',neutralReviewText:'请重新检查棋盘，可保留初选或修改为你认为正确的落点。',finalSubmit:'提交最终选择',confirmContinue:'确认并继续',step:'{current} / 10',timeoutNotice:'本题时间到，结果已记录并进入下一题。',withdraw:'退出本次',withdrawTitle:'确认退出本次？',withdrawCopy:'已保存的记录会保留；尚未完成的题目不会作为已提交答案。确认后可在结束页导出记录。',continue:'继续答题',confirmExit:'确认退出',adviceWarning:'建议仅用于本次条件练习；可保留初选，也可重新检查后选择。',adviceEyebrow:'练习复查',questionEyebrow:'A FORM · FINAL',surveyTitle:'简短问卷',optional:'可留空',surveyNote:'输入草稿会保存在本机；刷新后恢复。未提交草稿不会转交给下一位参与者。',experience:'你平时下五子棋的经验',difficulty:'你觉得这套题整体有多难？',helpfulness:'复查阶段对你有多大帮助？',trust:'你对本次AI建议的信任程度？',other:'其他意见',optionalPlaceholder:'可选',finishSurvey:'结束并查看导出',saved:'RUN SAVED',withdrawn:'已退出本次',completed:'A套已结束',exportSummary:'匿名编号 {id} · {condition} · {mode} · 包含10条题目结果/未完成状态',completeWarning:'本机保存失败；请先导出并联系工作人员。',exportJson:'导出完整 JSON',exportCsv:'导出逐题 CSV',next:'下一位参与者',footer:'A套试跑版 · 本机记录 · 不代表三套材料已等难或研究协议已冻结。',fatalTitle:'实验材料暂不可用',langButton:'English',hostParticipantsAria:'参与链接',hostReadyError:'主持人链接状态无效',runIntegrityError:'运行状态不完整，请导出记录并联系工作人员。',errors:{'需要先确认知情同意':'需要先确认知情同意','当前没有可退出的运行':'当前没有可退出的运行','请选择棋盘内空点':'请选择棋盘内空点','请先选择初选落点':'请先选择初选落点','请先选择最终落点':'请先选择最终落点'}},
 en:{title:'Form A Decision Study',description:'Local Form A decision-study preview',brand:'Study',brandPrefix:'Gomoku',brandAria:'Return to host page',pill:'Form A · Stored on this device',heroEyebrow:'FORM A · 10 ITEMS',hero:'Think independently, <em>then review one more step.</em>',intro:'3 baseline · 4 practice · 3 AI-free post-test items. All records stay in this browser.',startEyebrow:'START',startTitle:'Start Form A',localPilot:'Local preview',startIntro:'Read the information and consent to take part. No name, student ID, or contact details are required. An anonymous ID is generated on this device.',modeLegend:'Run mode',demoMode:'Demo mode',demoModeHelp:'Choose AI or control manually; the run is marked demo.',pilotMode:'Local pilot record',pilotModeHelp:'AI/control assigned in local paired blocks; this is not approved formal data collection.',conditionLegend:'Demo condition',ai:'AI suggestions',control:'Self-review',consentTitle:'Participant information',consentBullets:['This activity has 10 one-move attack/defence puzzles and takes about 15–20 minutes; actual time is recorded by the page.','You may withdraw at any time. Completed local records are retained and can be exported.','No suggestions or correctness feedback appear during baseline or post-test; practice condition prompts appear only after the initial choice is locked.','Anonymous ID, choices, timing, questionnaire answers, and version information are stored on this device. Demo and pilot records are labelled separately.','Static web materials may be inspected; this version does not promise to hide answers or suggestions from someone familiar with the source files.'],consent:'I have read the information and voluntarily agree to this local run. I understand I may withdraw at any time.',begin:'Start baseline →',hostAssignment:'Host-assigned',hostAssignmentAI:'Host-assigned: AI suggestions',hostAssignmentControl:'Host-assigned: Self-review',pairId:'Pair ID: {id}',pairMissing:'No pair ID provided',hostLock:'The host assigned this condition; it cannot be changed on this page.',agreeWait:'Agree and wait to start',readyEyebrow:'READY · A',readyTitle:'Ready, waiting for the host',readyIntro:'The timer has not started. Wait for the host to confirm both participants are ready and give the shared cue. After the cue, click below on this device. This page cannot remotely start or sync another device.',returnInfo:'Back to information',beginAfterCue:'Start Form A after the cue',stage:{baseline:'Baseline',practice:'Practice',posttest:'AI-free post-test'},youPlay:'You play',black:'Black',white:'White',moveObjective:{win:'It is your turn. Play one move that immediately makes five or more in a row.',block:'It is your turn. Block every opponent next move that would make five; an immediate win for you is also correct.'},timerLeft:'Time left',timerInitial:'Initial choice time',timerReview:'Time left for this item',demo:'Demo',pilot:'Local pilot',aiCondition:'AI condition',controlCondition:'Control condition',noFeedback:'Choice recorded only; no correctness feedback is shown here',blackStone:'Black stone',whiteStone:'White stone',empty:'Empty point',board:'board',boardCorner:'board, top-left A1',legendBlack:'Black',legendWhite:'White',keyboard:'Arrow keys move · Enter selects',selection:'Current selection',waiting:'—',baselineCopy:'Choose one move independently and confirm. No suggestion or correctness feedback is shown in this phase.',practiceInitial:'Choose one move independently. Confirm to lock your initial choice and continue to review.',lockInitial:'Lock initial choice',practiceReview:'Initial choice locked: {move}. Keep it or choose a final move on the board.',adviceMissing:'Suggestion unavailable',adviceMissingText:'The suggestion for this item is missing; this run has been paused.',adviceMove:'Suggested move: {move}',neutralReview:'Self-review',neutralReviewText:'Review the board again. Keep your initial choice or change it to the move you think is best.',finalSubmit:'Submit final choice',confirmContinue:'Confirm and continue',step:'{current} / 10',timeoutNotice:'Time expired for this item. It was recorded and the next item is ready.',withdraw:'Withdraw',withdrawTitle:'Withdraw from this run?',withdrawCopy:'Saved records will be retained. Unfinished items will not count as submitted answers. You can export the run from the completion page.',continue:'Continue answering',confirmExit:'Confirm withdrawal',adviceWarning:'Suggestion for this condition only. You may keep your initial move or review and choose again.',adviceEyebrow:'Practice review',questionEyebrow:'A FORM · FINAL',surveyTitle:'Short questionnaire',optional:'Optional',surveyNote:'Draft answers are saved on this device and restored after refresh. Unsubmitted answers will not carry over to the next participant.',experience:'How much Gomoku experience do you have?',difficulty:'How difficult were these items overall?',helpfulness:'How helpful was the review stage?',trust:'How much did you trust the AI suggestions?',other:'Additional comments',optionalPlaceholder:'Optional',finishSurvey:'Finish and view exports',saved:'RUN SAVED',withdrawn:'Run withdrawn',completed:'Form A complete',exportSummary:'Anonymous ID {id} · {condition} · {mode} · 10 item results/statuses included',completeWarning:'Local saving failed. Export this run first and contact the host.',exportJson:'Export full JSON',exportCsv:'Export item CSV',next:'Next participant',footer:'Form A preview · Local records · Does not certify form equivalence or a frozen research protocol.',fatalTitle:'Study materials unavailable',hostParticipantsAria:'Participant links',hostReadyError:'The host link is invalid.',runIntegrityError:'The saved run is incomplete or does not match this item. Export it and contact the host.',langButton:'中文',errors:{'需要先确认知情同意':'Consent is required before starting.','当前没有可退出的运行':'There is no active run to withdraw from.','请选择棋盘内空点':'Choose an empty point on the board.','请先选择初选落点':'Choose an initial move first.','请先选择最终落点':'Choose a final move first.'}}
};
let labels=language==='en'?{baseline:'Baseline',practice:'Practice',posttest:'AI-free post-test'}:{baseline:'基础测',practice:'正式练习',posttest:'无AI后测'};
const esc=s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
let toastTimer;
const fill=(value,vars={})=>Object.entries(vars).reduce((text,[name,replacement])=>text.replaceAll('{'+name+'}',String(replacement)),value);
const withForm = value => typeof value === 'string'
  ? value.replace(/(?<=Form |FORM |READY · )A\b|A(?= ?套| FORM)/g, formId)
  : value;
const tx=(key,vars={})=>fill(withForm(t[language][key]??t['zh-CN'][key]??key),vars);
const runtimeEnglishErrors=new Map([
  ['参与链接卷号无效','The assigned form is invalid. Ask the host for a fresh link.'],
  ['参与链接卷号与组号不一致','The form does not match the group ID. Ask the host for a fresh link.'],
  ['此浏览器有进行中的作答，请先使用原链接完成或退出','An answer session is already in progress. Use the original link to finish or withdraw from it.'],
  ['实验材料未包含在本地构建中','The assigned form is missing from this build. Reload or contact the host.'],
  ['实验材料完整性核对失败','Material integrity verification failed. Reload or contact the host.'],
  ['实验材料题序/题量不匹配','The form has an unexpected item order or count.'],
  ['实验材料或协议版本不匹配','The material or protocol version does not match this build.'],
  ['参与链接运行模式无效','This participant link has an unsupported run mode. Ask the host for a fresh link.'],['主持人链接缺少条件','This host link is missing its assigned condition. Ask the host for a fresh link.'],['主持人链接条件无效；请联系主持人重新分配','This host link has an invalid condition. Ask the host to assign AI or control again.'],['主持人链接配对编号无效','This host link has an invalid pair ID. Ask the host for a corrected link.'],
  ['A套材料未包含在本地构建中','Form A materials are missing from this build. Rebuild the Pages package or contact the host.'],['A套材料完整性核对失败','Form A material integrity verification failed. Do not start this run; contact the host.'],['A套题量/阶段配置不匹配','The Form A item count or stage configuration does not match this build. Contact the host.'],['A套协议版本/哈希不匹配','The Form A protocol version or hash does not match this build. Contact the host.'],['A套规则或材料版本不匹配','The Form A rules or material version does not match this build. Contact the host.'],
  ['A套材料不可用','Form A materials are unavailable in this page. Reload or contact the host.'],['A套题序/题量不匹配','The saved run does not use the fixed 10-item Form A order. Export it and contact the host.'],['A套记录格式不受支持','Saved Form A data has an unsupported format. It was not overwritten; export it or contact the host.'],['A套记录版本不匹配；旧记录未覆盖，请先导出并联系工作人员。','Saved Form A data uses a different protocol version. It was not overwritten; export it before continuing.'],['A套运行材料/hash不匹配；旧记录未覆盖，请先导出并联系工作人员。','Saved Form A data does not match the loaded material hashes. It was not overwritten; export it and contact the host.'],
  ['需要先确认知情同意','Consent is required before continuing.'],['未知运行模式','The selected run mode is invalid. Return to the host page.'],['运行语言无效','The saved interface language is invalid. Export the run and contact the host.'],['主持人链接必须使用pilot模式','This assigned-condition link must use pilot mode. Ask the host for a fresh link.'],['配对编号只用于主持人链接试跑','Pair IDs are only valid for host-assigned pilot links.'],['本机存储不可用；不能启动pilot运行','This browser cannot save local data, so a pilot run cannot start. Use an approved browser or contact the host.'],['演示模式请选择条件','Choose an AI or control condition for this demo.'],['主持人链接条件无效','The host-assigned condition is invalid. Ask the host for a fresh link.'],['当前没有可退出的运行','There is no active run to withdraw from.'],['请先结束或退出上一位参与者，并归档后再开始下一位','Finish or withdraw the previous run, then archive it before starting the next participant.'],['本题时间已到，已自动进入下一题','This item timed out and the next item is ready.'],['当前没有可作答的题目','There is no active item to answer.'],['请选择棋盘内空点','Choose an empty point on the board.'],['当前不是练习初选阶段','An initial choice can only be locked during the practice phase.'],['请先选择初选落点','Choose an initial move before locking it.'],['初选评分器不可用','The initial-choice scorer is unavailable. Contact the host.'],['核心未能记录初选；此题未锁定','The rules engine could not validate the initial move, so it was not locked. Choose another point or contact the host.'],['当前没有可提交结果','There is no active answer to submit.'],['请先选择最终落点','Choose a final move before submitting.'],['当前阶段不可提交最终选择','The final choice cannot be submitted in this phase.'],['规则核心未能评分；此题未记录','The rules engine could not score this move, so the item was not recorded. Contact the host.'],['初选复算不一致；此题未记录','The initial choice failed re-scoring, so the item was not recorded. Contact the host.'],['请先完成10道题','Complete all 10 items before submitting the questionnaire.'],['问卷当前未开放','The questionnaire is not currently available.'],['上一位参与者尚未结束','The previous participant has not finished or withdrawn yet.']
]);
function localizedError(error){const raw=String(error?.message??error);if(language!=='en')return raw;if(runtimeEnglishErrors.has(raw))return runtimeEnglishErrors.get(raw);if(/^题目配置错误：/.test(raw))return`A Form A item has invalid task metadata (${raw.split('：').at(-1)}). Reload the page or contact the host.`;if(/须为1到5或留空/.test(raw))return'Choose a rating from 1 to 5, or leave that field blank.';if(/配对编号仅允许/.test(raw))return'Pair IDs may contain 1–40 letters, digits, underscores, or hyphens.';if(/无法持久化pilot运行/.test(raw))return'This browser could not save the pilot run, so the run did not start. Use an approved browser or contact the host.';return'The requested action could not be completed. Check your selection and try again, or contact the host.';}
function localizedStorageIssue(issue){if(language!=='en')return issue;if(issue.includes('本机记录不可读'))return'Saved local data could not be read and was not overwritten. Export any available run and contact the host.';if(issue.includes('本机存储失败'))return'This browser could not save the latest change. The current run remains in memory; export it before closing this page.';if(issue.includes('时钟'))return'A clock inconsistency was detected. Affected item durations are marked invalid and will not be treated as zero.';return'A local storage or timing issue was detected. Export your run and contact the host.';}
function toast(message){ui.toast.textContent=typeof message==='string'&&t[language].errors[message]?t[language].errors[message]:language==='en'?localizedError({message}):message;ui.toast.hidden=false;ui.toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>ui.toast.classList.remove('show'),2600);}
function textNode(node,value){if(node)node.textContent=value;}
function labelWithControl(selector,value){const control=$(selector),label=control?.closest('label');if(label?.firstChild)label.firstChild.nodeValue=value+' ';}
function setLanguage(next,{writeUrl=true}={}){
  const run=session?.view().active_run;if(run)return;
  language=next==='en'?'en':'zh-CN';labels=language==='en'?{baseline:'Baseline',practice:'Practice',posttest:'AI-free post-test'}:{baseline:'基础测',practice:'正式练习',posttest:'无AI后测'};
  if(writeUrl){const url=new URL(location.href);if(language==='en')url.searchParams.set('lang','en');else url.searchParams.delete('lang');history.replaceState({},'',url);}
  applyLanguage();render();
}
function applyLanguage(){
  const x=Object.fromEntries(Object.entries(t[language]).map(([key,value])=>[key,withForm(value)])),english=language==='en';document.documentElement.lang=language;document.title=x.title;$('#meta-description').content=x.description;ui.languageToggle.textContent=x.langButton;ui.languageToggle.hidden=Boolean(session?.view().active_run);
  const brand=$('.brand');brand.setAttribute('aria-label',x.brandAria);brand.href=language==='en'?'./?lang=en':'./';brand.querySelector('.brand-light').textContent=x.brand;brand.querySelector(':scope > span:last-child').childNodes[0].nodeValue=x.brandPrefix+' ';
  $('.local-pill').lastChild.textContent=' '+x.pill+(formId!=='A'?(english?' · Pilot form':' · 预试卷'):'');$('.experiment-hero .eyebrow').textContent=x.heroEyebrow;$('.experiment-hero h1').innerHTML=x.hero;$('.experiment-hero p:last-child').textContent=x.intro;
  textNode($('#fatal h2'),x.fatalTitle);textNode($('#start-panel .eyebrow'),x.startEyebrow);textNode($('#start-panel h2'),x.startTitle);textNode($('#start-panel .card-heading .pill'),x.localPilot);textNode($('#start-panel > p'),x.startIntro);
  textNode($('#start-panel .mode-choice:not(.compact) legend'),x.modeLegend);
  const modeLabels=document.querySelectorAll('.mode-choice:not(.compact) label');[[x.demoMode,x.demoModeHelp],[x.pilotMode,x.pilotModeHelp]].forEach((values,index)=>{textNode(modeLabels[index]?.querySelector('b'),values[0]);textNode(modeLabels[index]?.querySelector('small'),values[1]);});
  textNode($('#demo-condition legend'),x.conditionLegend);const conditionLabels=document.querySelectorAll('#demo-condition label b');textNode(conditionLabels[0],x.ai);textNode(conditionLabels[1],x.control);
  textNode($('#start-panel .consent-copy h3'),x.consentTitle);
  [...document.querySelectorAll('#start-panel .consent-copy li')].forEach((item,index)=>textNode(item,x.consentBullets[index]));textNode($('#consent').nextElementSibling,x.consent);ui.startButton.textContent=x.begin;
  textNode($('#host-condition-label'),hostLink?(hostLink.condition==='AI'?x.hostAssignmentAI:x.hostAssignmentControl):'');textNode($('#host-pair-label'),hostLink?(hostLink.pair_id?tx('pairId',{id:hostLink.pair_id}):x.pairMissing):'');textNode($('#host-assignment p'),x.hostLock);
  $('#host-assignment').setAttribute('aria-label',x.hostParticipantsAria);
  textNode($('#host-ready-panel .eyebrow'),x.readyEyebrow);textNode($('#host-ready-panel h2'),x.readyTitle);const readyPs=$('#host-ready-panel').querySelectorAll('p');textNode(readyPs[1],x.readyIntro);textNode(ui.hostReturnConsent,x.returnInfo);textNode(ui.hostBeginRun,x.beginAfterCue);
  const selectedLabel=ui.selected.firstChild;if(selectedLabel?.nodeType===Node.TEXT_NODE)selectedLabel.nodeValue=x.selection+' ';
  textNode(ui.withdraw,x.withdraw);
  textNode($('.board-foot > span:nth-child(1)').lastChild,x.legendBlack);textNode($('.board-foot > span:nth-child(2)').lastChild,x.legendWhite);textNode($('.keyboard-hint'),x.keyboard);
  textNode($('#advice-warning'),x.adviceWarning);textNode($('#advice-card .eyebrow'),x.adviceEyebrow);
  textNode($('#questionnaire .eyebrow'),x.questionEyebrow);textNode($('#questionnaire h2'),x.surveyTitle);textNode($('#questionnaire .pill'),x.optional);textNode($('#questionnaire-note'),x.surveyNote);
  labelWithControl('#gomoku-experience',x.experience);labelWithControl('#comment',x.other);textNode($('#difficulty-scale').previousElementSibling,x.difficulty);textNode($('#help-scale').previousElementSibling,x.helpfulness);textNode($('#trust-question p'),x.trust);
  $('#gomoku-experience').placeholder=x.optionalPlaceholder;$('#comment').placeholder=x.optionalPlaceholder;textNode(ui.finish,x.finishSurvey);
  textNode($('#withdraw-confirmation h3'),x.withdrawTitle);textNode($('#withdraw-confirmation-copy'),x.withdrawCopy);textNode(ui.withdrawContinue,x.continue);textNode(ui.withdrawConfirm,x.confirmExit);
  textNode($('#complete-panel .eyebrow'),x.saved);textNode($('#export-json'),x.exportJson);textNode($('#export-csv'),x.exportCsv);textNode(ui.next,x.next);textNode($('.experiment-footer'),x.footer);
  if(ui.modeChoice)ui.modeChoice.hidden=Boolean(hostLink);
}
function hideAll(){ui.start.hidden=true;ui.hostReady.hidden=true;ui.run.hidden=true;ui.questionnaire.hidden=true;ui.complete.hidden=true;}
function storageAdapter(){try{return{getItem:k=>localStorage.getItem(k),setItem:(k,v)=>localStorage.setItem(k,v)};}catch(error){return{getItem:()=>{throw error;},setItem:()=>{throw error;}};}}
function parseHostLink(){
  const params=new URLSearchParams(location.search);
  const condition=params.get('condition'), mode=params.get('mode'), rawPair=params.get('pair_id');
  const assignedForm=params.get('form');
  if(assignedForm!==null&&!FORM_IDS.includes(assignedForm)) throw new Error('参与链接卷号无效');
  formId=assignedForm??'A';
  if(mode&&mode!=='pilot_link') throw new Error('参与链接运行模式无效');
  if(!condition){
    if(mode==='pilot_link'||rawPair!==null) throw new Error('主持人链接缺少条件');
    return null;
  }
  if(!['AI','control'].includes(condition)) throw new Error('主持人链接条件无效；请联系主持人重新分配');
  const pair_id=rawPair?.trim()||null;
  if(pair_id&&!isPairId(pair_id)) throw new Error('主持人链接配对编号无效');
  if(assignedForm!==null&&(!pair_id||formForPair(pair_id)!==assignedForm)) {
    throw new Error('参与链接卷号与组号不一致');
  }
  return {mode:'pilot_link',condition,pair_id};
}
function feedbackStorage(){if(!session)return;const issues=session.issues;ui.notice.hidden=!issues.length;ui.notice.textContent=issues.length?(language==='en'?issues.map(localizedStorageIssue).join(' '):issues.join(' ')):'';}
function available(pos,item){return !item.board.pieces.some(x=>x.pos===pos);}
function addBoardGrid(){
  const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('class','exp-grid-lines');svg.setAttribute('viewBox','0 0 560 560');svg.setAttribute('aria-hidden','true');
  let d='';for(let i=0;i<15;i++){const n=21+37*i;d+=`M21 ${n}H539 M${n} 21V539`;const col=document.createElementNS(ns,'text');col.setAttribute('x',n);col.setAttribute('y','14');col.setAttribute('text-anchor','middle');col.textContent=String.fromCharCode(65+i);svg.append(col);const row=document.createElementNS(ns,'text');row.setAttribute('x','9');row.setAttribute('y',n+4);row.setAttribute('text-anchor','middle');row.textContent=String(i+1);svg.append(row);}const path=document.createElementNS(ns,'path');path.setAttribute('d',d);path.setAttribute('fill','none');path.setAttribute('stroke','#806b4788');path.setAttribute('stroke-width','1');svg.prepend(path);ui.board.append(svg);
}
function moveKeyboard(event,row,col,item){if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();let r=row,c=col;for(let tries=0;tries<225;tries++){if(event.key==='ArrowUp')r--;if(event.key==='ArrowDown')r++;if(event.key==='ArrowLeft')c--;if(event.key==='ArrowRight')c++;if(r<0||r>14||c<0||c>14)return;const pos=String.fromCharCode(65+c)+(r+1);if(!available(pos,item))continue;ui.board.querySelector(`[data-pos="${pos}"]`)?.focus();return;}}
function renderBoard(item,selected,active){ui.board.replaceChildren();ui.board.setAttribute('aria-label',language==='en'?`${item.id}, 15 by 15 Gomoku board, top-left A1`:`${item.id}，15乘15棋盘，左上A1`);addBoardGrid();
  const run=session.view().active_run;
  for(let row=0;row<15;row++)for(let col=0;col<15;col++){
    const pos=String.fromCharCode(65+col)+(row+1),stone=item.board.pieces.find(x=>x.pos===pos),button=document.createElement('button');button.type='button';button.className='exp-point';button.style.left=`${((21+37*col)/560)*100}%`;button.style.top=`${((21+37*row)/560)*100}%`;button.dataset.pos=pos;
    button.setAttribute('aria-label',`${pos} ${stone?(stone.color==='B'?tx('blackStone'):tx('whiteStone')):tx('empty')}`);
    if(stone){button.disabled=true;const dot=document.createElement('span');dot.className=`stone ${stone.color==='B'?'black':'white'}`;button.append(dot);}
    else{button.disabled=!active;if(selected===pos)button.classList.add('selected');button.addEventListener('click',()=>{try{session.selectMove(pos);render();}catch(error){toast(error.message);}});button.addEventListener('keydown',e=>moveKeyboard(e,row,col,item));}
    ui.board.append(button);
  }
}
function score(item,pos){return evaluate_move({rules_version:study.rules_version,board:item.board,side_to_move:item.side_to_move,task:item.task,move:{pos,color:item.side_to_move}});}
function formatTime(ms){const seconds=Math.max(0,Math.ceil(ms/1000));return`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;}
function renderScale(containerId,name){const container=$(containerId);container.replaceChildren();for(let n=1;n<=5;n++){const label=document.createElement('label'),input=document.createElement('input'),span=document.createElement('span');input.type='radio';input.name=name;input.value=String(n);span.textContent=String(n);label.append(input,span);container.append(label);}}
function questionnaireValues(){const val=name=>{const v=document.querySelector(`input[name="${name}"]:checked`)?.value;return v?Number(v):null;};return{gomoku_experience:$('#gomoku-experience').value.trim()||null,perceived_difficulty:val('difficulty'),review_helpfulness:val('help'),ai_trust:val('trust'),comment:$('#comment').value.trim()||null};}
function restoreQuestionnaire(draft={}){$('#gomoku-experience').value=draft.gomoku_experience??'';$('#comment').value=draft.comment??'';for(const[name,key]of [['difficulty','perceived_difficulty'],['help','review_helpfulness'],['trust','ai_trust']])for(const input of document.querySelectorAll(`input[name="${name}"]`))input.checked=String(draft[key]??'')===input.value;}
function clearQuestionnaire(){restoreQuestionnaire({});}
function saveQuestionnaireDraft(){try{session.updateQuestionnaireDraft(questionnaireValues());}catch(error){toast(error.message);}}
function openWithdrawConfirmation(){if(withdrawalSubmitting)return;ui.withdrawConfirmation.hidden=false;ui.withdraw.setAttribute('aria-expanded','true');ui.withdrawContinue.focus();}
function closeWithdrawConfirmation(returnFocus=true){ui.withdrawConfirmation.hidden=true;ui.withdraw.setAttribute('aria-expanded','false');if(returnFocus)ui.withdraw.focus();}
function confirmWithdrawal(){if(withdrawalSubmitting||ui.withdrawConfirmation.hidden)return;withdrawalSubmitting=true;ui.withdrawConfirm.disabled=true;try{session.withdraw();render();ui.exportJson.focus();}catch(error){withdrawalSubmitting=false;ui.withdrawConfirm.disabled=false;toast(error.message);}}
function render(){
  if(!session)return;feedbackStorage();const v=session.viewWithTimer(),run=v.active_run;hideAll();
  ui.languageToggle.hidden=Boolean(run);
  lastRenderKey=run?`${run.run_id}|${run.status}|${run.current_index}|${run.phase}`:null;
  if(!run){
    if(hostLink){ui.modeChoice.hidden=true;ui.demoCondition.hidden=true;ui.hostAssignment.hidden=false;ui.startModePill.textContent=tx('hostAssignment');ui.hostConditionLabel.textContent=hostLink.condition==='AI'?t[language].hostAssignmentAI:t[language].hostAssignmentControl;ui.hostPairLabel.textContent=hostLink.pair_id?tx('pairId',{id:hostLink.pair_id}):tx('pairMissing');ui.hostReady.hidden=!hostReady;ui.start.hidden=hostReady;ui.hostReadySummary.textContent=(hostLink.condition==='AI'?t[language].hostAssignmentAI:t[language].hostAssignmentControl)+' · '+(hostLink.pair_id?tx('pairId',{id:hostLink.pair_id}):tx('pairMissing'));ui.startButton.textContent=tx('agreeWait');ui.startButton.disabled=!ui.consent.checked;return;}
    ui.start.hidden=false;ui.modeChoice.hidden=false;ui.hostAssignment.hidden=true;ui.demoCondition.hidden=ui.mode()!=='demo';ui.startModePill.textContent=tx('localPilot');ui.startButton.textContent=tx('begin');ui.startButton.disabled=!ui.consent.checked;return;
  }
  if(run.status==='in_progress'){
    ui.run.hidden=false;const index=run.current_index,rec=run.items[index],item=study.items[index];if(!rec||!item){ui.fatal.hidden=false;ui.fatalMessage.textContent=tx('runIntegrityError');ui.run.hidden=true;return;}
    const side=item.side_to_move==='B'?tx('black'):tx('white'),phase=run.phase,practice=item.stage==='practice';
    ui.stage.textContent=labels[item.stage];ui.title.textContent=language==='en'?`Question ${index+1} · ${tx('youPlay')} ${side}`:`第${index+1}题 · 你执${side}`;
    const objective=item.task.type==='win_in_1'?tx('moveObjective.win'):tx('moveObjective.block');
    ui.instruction.textContent=language==='en'?`${tx('youPlay')} ${side}. ${objective}`:`你执${side}方。本题目标：${item.prompt_zh}`;
    const modeName=run.mode==='demo'?tx('demo'):run.allocation_kind==='host_link'?tx('pilot'):(language==='en'?'Local pilot':'本机试跑');
    ui.meta.textContent=`${run.participant_id} · ${modeName} · ${run.condition==='AI'?tx('aiCondition'):tx('controlCondition')} · ${tx('noFeedback')}`;
    const remaining=phase==='initial'&&v.initial_remaining_ms!==null?v.initial_remaining_ms:v.time_remaining_ms??0;
    ui.timerLabel.textContent=phase==='initial'?tx('timerInitial'):phase==='review'?tx('timerReview'):tx('timerLeft');ui.timer.textContent=formatTime(remaining);
    ui.progress.style.width=`${Math.round(index/10*100)}%`;ui.stepCount.textContent=tx('step',{current:index+1});
    const selected=rec.selected_move??(phase==='review'?rec.initial_move:null);ui.selected.querySelector('strong').textContent=selected??'—';renderBoard(item,selected,true);
    if(practice&&phase==='initial'){
      ui.phasePanel.hidden=false;ui.advice.hidden=true;ui.phaseCopy.textContent=tx('practiceInitial');ui.phaseButton.textContent=tx('lockInitial');ui.phaseButton.disabled=!selected;ui.phaseButton.onclick=()=>{try{session.confirmInitial(score);render();}catch(error){toast(error.message);}};
    }else if(practice&&phase==='review'){
      ui.phasePanel.hidden=false;ui.advice.hidden=false;ui.phaseCopy.textContent=tx('practiceReview',{move:rec.initial_move});
      if(run.condition==='AI'){const suggestion=v.advice;if(!suggestion){ui.adviceTitle.textContent=tx('adviceMissing');ui.adviceCopy.textContent=tx('adviceMissingText');ui.phaseButton.disabled=true;}else{ui.adviceTitle.textContent=tx('adviceMove',{move:suggestion.move});ui.adviceCopy.textContent=language==='en'?(suggestion.reason_en??suggestion.reason_zh):suggestion.reason_zh;ui.phaseButton.disabled=false;}}
      else{ui.adviceTitle.textContent=tx('neutralReview');ui.adviceCopy.textContent=tx('neutralReviewText');ui.phaseButton.disabled=false;}
      ui.phaseButton.textContent=tx('finalSubmit');ui.phaseButton.onclick=()=>{try{session.submitFinal(score);render();}catch(error){toast(error.message);}};
    }else{
      ui.phasePanel.hidden=false;ui.advice.hidden=true;ui.phaseCopy.textContent=tx('baselineCopy');ui.phaseButton.textContent=tx('confirmContinue');ui.phaseButton.disabled=!selected;ui.phaseButton.onclick=()=>{try{session.submitFinal(score);render();}catch(error){toast(error.message);}};
    }
    return;
  }
  if(run.status==='questionnaire'){
    ui.questionnaire.hidden=false;$('#trust-question').hidden=run.condition!=='AI';restoreQuestionnaire(run.questionnaire_draft??{});return;
  }
  if(['complete','withdrawn'].includes(run.status)){
    ui.complete.hidden=false;ui.completeTitle.textContent=run.status==='withdrawn'?tx('withdrawn'):tx('completed');ui.completeSummary.textContent=fill(tx('exportSummary'),{id:run.participant_id,condition:run.condition==='AI'?tx('aiCondition'):tx('controlCondition'),mode:run.mode==='demo'?tx('demo'):(language==='en'?'Pilot':'本机试跑记录')});
    ui.completeWarning.hidden=session.persisted;ui.completeWarning.textContent=session.persisted?'':tx('completeWarning');return;
  }
}
function timerTick(){
  if(!session)return;const v=session.viewWithTimer(),run=v.active_run;
  const key=run?`${run.run_id}|${run.status}|${run.current_index}|${run.phase}`:null;
  if(key!==lastRenderKey){const oldIndex=Number(lastRenderKey?.split('|')[2]);if(run?.items?.[oldIndex]?.timeout)toast(tx('timeoutNotice'));render();return;}
  if(run?.status==='in_progress'){
    const ms=run.phase==='initial'&&v.initial_remaining_ms!==null?v.initial_remaining_ms:v.time_remaining_ms??0;
    ui.timerLabel.textContent=run.phase==='initial'?tx('timerInitial'):run.phase==='review'?tx('timerReview'):tx('timerLeft');ui.timer.textContent=formatTime(ms);ui.progress.style.width=`${Math.round(run.current_index/10*100)}%`;
  }
}
function download(name,type,contents){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([contents],{type}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
async function init(){
  try{
    hostLink=parseHostLink();
    const materials=await loadForm(formId);
    study=materials.study;
    session=createExperimentSession({study,advice:materials.advice,storage:storageAdapter()});
    const active=session.view().active_run;
    if(hostLink&&active&&['in_progress','questionnaire'].includes(active.status)&&
       (active.allocation_kind!=='host_link'||active.condition!==hostLink.condition||active.pair_id!==hostLink.pair_id)) {
      throw new Error('此浏览器有进行中的作答，请先使用原链接完成或退出');
    }
    renderScale('#difficulty-scale','difficulty');renderScale('#help-scale','help');renderScale('#trust-scale','trust');const existingRun=session.view().active_run;if(existingRun)language=existingRun.ui_language??'zh-CN';applyLanguage();render();ui.consent.addEventListener('change',render);for(const r of document.querySelectorAll('input[name="mode"]'))r.addEventListener('change',render);
    ui.languageToggle.addEventListener('click',()=>setLanguage(language==='en'?'zh-CN':'en'));
    ui.startButton.addEventListener('click',()=>{try{if(hostLink){if(!ui.consent.checked)throw new Error('需要先确认知情同意');hostReady=true;render();ui.hostBeginRun.focus();return;}session.beginRun({mode:ui.mode(),manual_condition:ui.condition(),consent:ui.consent.checked,ui_language:language});render();}catch(error){toast(localizedError(error));}});
    ui.hostReturnConsent.addEventListener('click',()=>{hostReady=false;render();ui.consent.focus();});
    ui.hostBeginRun.addEventListener('click',()=>{try{if(!hostLink||!hostReady)throw new Error('主持人链接状态无效');session.beginRun({mode:'pilot',manual_condition:hostLink.condition,allocation_kind:'host_link',pair_id:hostLink.pair_id,consent:true,ui_language:language});hostReady=false;render();}catch(error){toast(localizedError(error));}});
    ui.withdraw.addEventListener('click',openWithdrawConfirmation);
    ui.withdrawContinue.addEventListener('click',()=>closeWithdrawConfirmation());
    ui.withdrawConfirm.addEventListener('click',confirmWithdrawal);
    for(const field of document.querySelectorAll('#gomoku-experience,#comment,.questionnaire-card input[type="radio"]'))field.addEventListener('input',saveQuestionnaireDraft);
    for(const field of document.querySelectorAll('.questionnaire-card input[type="radio"]'))field.addEventListener('change',saveQuestionnaireDraft);
    ui.finish.addEventListener('click',()=>{try{session.setQuestionnaire(questionnaireValues());render();}catch(error){toast(error.message);}});
    ui.next.addEventListener('click',()=>{try{session.nextParticipant();withdrawalSubmitting=false;ui.withdrawConfirm.disabled=false;closeWithdrawConfirmation(false);ui.consent.checked=false;document.querySelector('input[name="mode"][value="demo"]').checked=true;document.querySelector('input[name="condition"][value="AI"]').checked=true;clearQuestionnaire();render();ui.consent.focus();}catch(error){toast(localizedError(error));}});
    $('#export-json').addEventListener('click',()=>download(`gomoku-study-${formId}.json`,'application/json;charset=utf-8',JSON.stringify(session.exportData(),null,2)));
    $('#export-csv').addEventListener('click',()=>download(`gomoku-study-${formId}.csv`,'text/csv;charset=utf-8','\ufeff'+session.exportCsv(language)));
    document.addEventListener('visibilitychange',()=>session.visibilityChanged(document.hidden));
    timerId=setInterval(timerTick,250);
  }catch(error){hideAll();ui.fatal.hidden=false;ui.fatalMessage.textContent=localizedError(error);}
}
init();
